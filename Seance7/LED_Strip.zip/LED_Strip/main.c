/**
 *
 */

#include "lib_led_strip.h"

int main() {
	//int i;
	
	//Définir pin 8 en out pour le latch
	//rflpc_gpio_set_pin_mode_output(0,6);
	
	//init_led_strip();
	/*
	while(1) {
		for(i = 0; i < LED_CNT ; i++) {
		
		SPI_WRITE(145);
		
		}
		
		//Latch
		rflpc_gpio_set_pin(0,6);
		RFLPC_DELAY(2);
		rflpc_gpio_clr_pin(0,6);
		
	}*/
	/*
	rflpc_uart_init(RFLPC_UART0);
   rflpc_timer_enable(RFLPC_TIMER0);
   rflpc_timer_set_clock(RFLPC_TIMER0,RFLPC_CCLK/8);
   rflpc_timer_set_pre_scale_register(RFLPC_TIMER0, rflpc_clock_get_system_clock()/8000000); /* microsecond timer */
   /*
   rflpc_timer_start(RFLPC_TIMER0);
   	test_spi_matrix();
   	while(1);
   	return 0;
   	*/
   	
   	while(1){
   		INIT_WAIT;
		SPI_INIT;
		int i;
		uint8_t pic = 0b11000011;
		rflpc_gpio_clr_pin(0,6);
		for (i = 0 ; i < NLED ; ++i) {
			SPI_WRITE(pic);
		}
		rflpc_gpio_set_pin(0,6);
		RFLPC_DELAY(2);
   }
   return 0;	
}
