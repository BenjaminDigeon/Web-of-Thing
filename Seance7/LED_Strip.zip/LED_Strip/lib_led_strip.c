/**
 * Librairie de commande du LED Strip
 * Benjamin Digeon
 * Florent David
 */

#include "lib_led_strip.h"

void led_display_buffer(uint8_t *buffer)
{
   	int i;
   	for (i = 0 ; i < NLED ; ++i) {
      rflpc_spi_write(SPI_PORT, buffer[i]);
	}
   	/* wait for transfer to finish */
   	while (!rflpc_spi_tx_fifo_empty(SPI_PORT));
}

void test_spi_matrix()
{
   uint8_t pic[NLED];

   /* The led matrix spi can be clock at maximum 125Khz, calc the needed dividers */
   int spi_peripheral_clock = rflpc_clock_get_system_clock() / 8;
   int needed_divider = spi_peripheral_clock / 125000;
   int serial_clock_rate_divider = 1;
   int i = 0;

   while (needed_divider / serial_clock_rate_divider > 254)
   {
      serial_clock_rate_divider++;
   }

   needed_divider /= serial_clock_rate_divider;
   rflpc_spi_init(SPI_PORT, RFLPC_SPI_MASTER, RFLPC_CCLK_8, 8, needed_divider, serial_clock_rate_divider);

   	while (1) {
		//vert : 0b11000011
		//bleu : 0b00110011
		//jaune : 0b00001111

		for (i = 0 ; i < NLED ; ++i) {
   			pic[i] = 0b01111111; // blanc
			led_display_buffer(pic);
			RFLPC_DELAY(300000);
		}
	
		for (i = 0 ; i < NLED ; ++i) {
   			pic[i] = 0b00001100; // rouge
			led_display_buffer(pic);
			RFLPC_DELAY(300000);
		}
   	}
}

void test_led_strip() {
	INIT_WAIT;
	SPI_INIT;
	int i;
	uint8_t pic = 0b11000011;
	for (i = 0 ; i < NLED ; ++i) {
		SPI_WRITE(pic);
	}
	RFLPC_DELAY(2);
}